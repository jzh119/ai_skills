#!/usr/bin/env python3
"""
vocab-html-builder: Generate interactive HTML vocabulary learning pages from word lists.

Supports input formats: xlsx, csv (with columns: word, chinese, phonetic, etymology)
For unstructured files (txt/pdf/docx), use extract_words.py first to get words_normalized.csv.

Features:
  - Pre-embedded Chinese translations (100% offline, no API calls at runtime)
  - Click-to-toggle Chinese (toggleCn) instead of hover
  - Neural TTS audio (edge-tts) for words and dialogues
  - Review system with localStorage persistence
  - Single-section display mode (CSS :target)

Usage:
  python build_vocab.py <input_file> [--output <dir>] [--per-section <n>] [--title <title>]
  python build_vocab.py words.xlsx --output ./result --per-section 20 --title "My Vocab List"
  python build_vocab.py words_normalized.csv --output ./result --per-section 20

Translation workflow:
  1. Run with --extract-sentences to output unique_sentences.json
  2. Use AI to translate all sentences -> cn_translations.py (CN = {"en": "zh", ...})
  3. Run again (without --extract-sentences) to build final HTML with translations embedded
"""

import pandas as pd
import re
import random
import sys
import os
import json
import argparse
import importlib.util

# ── CLI arguments ───────────────────────────────────────────────
def parse_args():
    parser = argparse.ArgumentParser(
        description='Generate interactive HTML vocabulary learning page from word list (xlsx/csv)'
    )
    parser.add_argument('input', help='Path to word list file (xlsx or csv)')
    parser.add_argument('--output', default='./output', help='Output directory (default: ./output)')
    parser.add_argument('--per-section', type=int, default=30, help='Words per section (default: 30)')
    parser.add_argument('--title', default=None, help='HTML page title (default: auto from filename)')
    parser.add_argument('--template', default=None,
                        help='Path to HTML template (default: assets/html-template.html in skill dir)')
    parser.add_argument('--translations', default=None,
                        help='Path to cn_translations.py (Python dict CN = {"en": "zh", ...}). '
                             'If not provided, looks for cn_translations.py in the same directory as input.')
    parser.add_argument('--extract-sentences', action='store_true',
                        help='Extract unique dialogue sentences to unique_sentences.json and exit '
                             '(for AI batch translation).')
    parser.add_argument('--custom-scenarios', default=None,
                        help='Path to custom_scenarios.json with additional dialogue templates '
                             '(for context-aware dialogues based on input file content). '
                             'Format: {"scenario_name": [["A line", "B line", "A line"], ...], ...}. '
                             'These are merged with built-in SCENARIOS.')
    return parser.parse_args()

args = parse_args()
sys.stdout.reconfigure(encoding='utf-8')

# ── Resolve template path ───────────────────────────────────────
TEMPLATE_PATH = args.template
if not TEMPLATE_PATH:
    script_dir = os.path.dirname(os.path.abspath(__file__))
    skill_dir = os.path.dirname(script_dir)
    candidate = os.path.join(skill_dir, 'assets', 'html-template.html')
    if os.path.exists(candidate):
        TEMPLATE_PATH = candidate
    else:
        home = os.path.expanduser('~')
        candidate2 = os.path.join(home, '.workbuddy', 'skills', 'vocab-html-builder',
                                  'assets', 'html-template.html')
        if os.path.exists(candidate2):
            TEMPLATE_PATH = candidate2
        else:
            print(f'ERROR: Template not found. Tried:\n  {candidate}\n  {candidate2}')
            print('Please provide --template path or ensure skill is installed.')
            sys.exit(1)

# ── Title auto-generation ──────────────────────────────────────
TITLE = args.title
if not TITLE:
    basename = os.path.splitext(os.path.basename(args.input))[0]
    TITLE = f'{basename} 词汇学习大全'

REVIEW_KEY = re.sub(r'[^\w]', '_', TITLE).lower()

# ── 1. Parse input file (xlsx or csv) ──────────────────────────
INPUT_EXT = os.path.splitext(args.input)[1].lower()
if INPUT_EXT in ('.xlsx', '.xls'):
    df = pd.read_excel(args.input)
elif INPUT_EXT == '.csv':
    # Try common encodings for CSV
    for _enc in ['utf-8', 'gbk', 'gb2312', 'latin-1']:
        try:
            df = pd.read_csv(args.input, encoding=_enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        print('ERROR: Could not decode CSV file. Try converting to UTF-8.')
        sys.exit(1)
else:
    print(f'ERROR: Unsupported format: {INPUT_EXT}. Use xlsx or csv.')
    print('For txt/pdf/docx files, run extract_words.py first to get words_normalized.csv')
    sys.exit(1)
cols = list(df.columns)
TOTAL = len(df)
WORDS_PER_SECTION = args.per_section
TOTAL_SECTIONS = (TOTAL + WORDS_PER_SECTION - 1) // WORDS_PER_SECTION

print(f'Input: {args.input}')
print(f'Total words: {TOTAL}, Sections: {TOTAL_SECTIONS}, Per section: {WORDS_PER_SECTION}')
print(f'Columns: {cols}')
print(f'Template: {TEMPLATE_PATH}')
print(f'Title: {TITLE}')
print(f'Review key: {REVIEW_KEY}')

# ── Column identification ──────────────────────────────────────
col_grade = None
col_unit  = None
col_word  = cols[2] if len(cols) > 2 else None
col_cn    = cols[3] if len(cols) > 3 else None
col_ph    = cols[4] if len(cols) > 4 else None
col_etym  = cols[5] if len(cols) > 5 else None

for i, c in enumerate(cols):
    cl = str(c).lower()
    if '年级' in cl or 'grade' in cl:
        col_grade = c
    if '单元' in cl or 'unit' in cl:
        col_unit = c
    if '单词' in cl or 'english' in cl or '英文' in cl or '术语' in cl or ('word' in cl and 'word' not in cl.replace('word', '')):
        col_word = c
    if '中文' in cl or 'chinese' in cl or '释义' in cl or '翻译' in cl or 'translation' in cl or 'meaning' in cl:
        col_cn = c
    if '音标' in cl or 'phonetic' in cl:
        col_ph = c
    if '词根' in cl or '词源' in cl or 'etymology' in cl or 'etym' in cl:
        col_etym = c

# ── CRITICAL: Auto-detect and fix swapped word/cn columns ─────
def has_chinese(text):
    """Check if a string contains any Chinese characters."""
    if pd.isna(text):
        return False
    return bool(re.search(r'[\u4e00-\u9fff]', str(text)))

def strip_chinese(text):
    """Remove all Chinese characters from a string, keeping spaces intact."""
    return re.sub(r'[\u4e00-\u9fff]+', '', str(text)).strip()

# Sample first 20 non-null words to check for Chinese content
if col_word and col_cn:
    sample_words = df[col_word].dropna().head(20)
    sample_cns = df[col_cn].dropna().head(20)
    cn_in_word_col = sum(1 for v in sample_words if has_chinese(v))
    en_in_cn_col = sum(1 for v in sample_cns if not has_chinese(v))
    if cn_in_word_col > len(sample_words) * 0.3:
        print(f'WARNING: {cn_in_word_col}/{len(sample_words)} values in word column contain Chinese.')
        print(f'         Auto-swapping col_word <-> col_cn')
        col_word, col_cn = col_cn, col_word
    elif en_in_cn_col > len(sample_cns) * 0.5:
        print(f'WARNING: {en_in_cn_col}/{len(sample_cns)} values in Chinese column appear to be English.')
        print(f'         Auto-swapping col_word <-> col_cn')
        col_word, col_cn = col_cn, col_word

print(f'Column mapping: word={col_word}, cn={col_cn}, grade={col_grade}, unit={col_unit}, ph={col_ph}, etym={col_etym}')

missing_ph = 0
missing_etym = 0
if col_ph:
    missing_ph = int(df[col_ph].isna().sum())
if col_etym:
    missing_etym = int(df[col_etym].isna().sum())

print(f'Missing phonetics: {missing_ph}, Missing etymology: {missing_etym}')

# ── Helper functions ────────────────────────────────────────────
def parse_phonetic(raw):
    """Parse combined phonetic string into UK/US pair."""
    if pd.isna(raw):
        return '', ''
    raw = str(raw).strip()
    uk, us = '', ''
    m_uk = re.search(r'英\s*[:：]\s*(/[^/]*/)', raw)
    m_us = re.search(r'美\s*[:：]\s*(/[^/]*/)', raw)
    if m_uk:
        uk = m_uk.group(1)
    if m_us:
        us = m_us.group(1)
    if not uk and not us:
        cleaned = raw.replace('英:', '').replace('美:', '').strip()
        if cleaned.startswith('/'):
            uk = cleaned
            us = cleaned
    return uk, us

def clean_etymology(raw):
    """Clean and shorten etymology text."""
    if pd.isna(raw):
        return '暂无词根词缀信息'
    text = str(raw).strip()
    if len(text) > 300:
        text = text[:297] + '...'
    return text

def guess_word_type(chinese):
    """Guess word type from Chinese meaning."""
    if pd.isna(chinese):
        return 'n.'
    c = str(chinese)
    if any(kw in c for kw in ['的', '地', '得']):
        return 'adj./adv.'
    if any(kw in c for kw in ['在', '是', '有', '做', '去', '来', '吃', '喝', '看', '听', '说',
                                '走', '跑', '写', '读', '放', '给', '拿', '穿', '开', '关', '飞',
                                '游', '唱', '画', '洗', '睡', '醒', '买', '卖', '送', '收', '找',
                                '用', '帮', '叫', '让', '想', '爱', '怕', '玩', '坐', '站']):
        return 'v.'
    if re.match(r'^[零一二三四五六七八九十百千万亿\d]+', c):
        return 'num.'
    if any(kw in c for kw in ['我', '你', '他', '她', '它', '我们', '他们', '这', '那', '什么', '谁', '哪']):
        return 'pron.'
    if any(kw in c for kw in ['不', '没', '很', '太', '也', '都', '还', '又', '再', '已经', '正在', '就']):
        return 'adv.'
    return 'n.'

def get_definition(word, chinese, wtype):
    """Build clean definition string."""
    if pd.isna(chinese) or not str(chinese).strip():
        return wtype + ' ' + str(word)
    return wtype + ' ' + str(chinese).strip()

# ── 2. Dialogue generation ──────────────────────────────────────

# Load custom scenarios from JSON file (context-aware dialogues)
CUSTOM_SCENARIOS = {}
if args.custom_scenarios and os.path.exists(args.custom_scenarios):
    with open(args.custom_scenarios, 'r', encoding='utf-8') as f:
        CUSTOM_SCENARIOS = json.load(f)
    print(f'Loaded {len(CUSTOM_SCENARIOS)} custom scenario groups: {list(CUSTOM_SCENARIOS.keys())}')
    # Normalize: each template must be a tuple of 3 strings (A, B, A)
    for key, templates in CUSTOM_SCENARIOS.items():
        if not isinstance(templates, list):
            print(f'  WARNING: "{key}" is not a list, skipping')
            del CUSTOM_SCENARIOS[key]
            continue
        normalized = []
        for t in templates:
            if isinstance(t, list) and len(t) == 3:
                normalized.append(tuple(t))
            else:
                print(f'  WARNING: template in "{key}" is not [A,B,A], skipping: {t}')
        if normalized:
            CUSTOM_SCENARIOS[key] = normalized
        else:
            del CUSTOM_SCENARIOS[key]

SCENARIOS = {
    'greeting': [
        ("Hi! How's everything going?", "Pretty good! I was just thinking about {}.", "Oh really? Tell me more about it."),
        ("Good to see you! What's new?", "Not much. I've been interested in {} lately.", "That sounds cool. What got you into it?"),
        ("Hey there! You seem cheerful today.", "I am! I finally understood what {} means.", "That's great! Understanding new words is always satisfying."),
        ("How's your day been?", "Interesting! I came across the word {} today.", "I've seen that word before. What does it refer to?"),
        ("Long time no see! What have you been up to?", "I've been reading a lot about {}.", "Nice! I'd love to hear what you learned."),
    ],
    'classroom': [
        ("Can you explain what {} means?", "Sure! Let me give you an example with {}.", "Thanks, that makes it much clearer now."),
        ("I'm not sure I understand {}.", "Let me break it down. {} refers to something specific.", "Oh, I see. Could you use it in another sentence?"),
        ("How do you use {} correctly?", "You can say something like: I need to check the {}.", "Got it. I'll try using it in my own sentence."),
        ("What's the difference between similar words?", "Well, {} has a particular meaning. Let me show you.", "Ah, now I understand the distinction."),
        ("I keep forgetting how to spell {}.", "Try breaking it down: {}. Repeat it a few times.", "Good tip! I'll practice writing it down."),
        ("Let's review the key terms together.", "OK, let's start with {}. What do you know about it?", "I know it's important. Let me try to define it."),
    ],
    'play': [
        ("What should we do now?", "How about we explore the idea of {}?", "Interesting! I've never thought about it that way."),
        ("I need a break. Any fun ideas?", "Let's make a game. Whoever uses {} in a sentence first wins!", "Challenge accepted!"),
        ("This is getting boring. Anything exciting?", "Did you know there's something fascinating about {}?", "No, tell me! I want to know."),
        ("Want to try something different?", "Sure! Let's talk about {} for a change.", "OK, you start. What's so special about it?"),
        ("Let's do something creative.", "How about we draw a picture related to {}?", "That's a fun idea. I'll give it a try."),
    ],
    'daily': [
        ("What's on your mind today?", "I've been dealing with {} all morning.", "That sounds busy. Is everything OK?"),
        ("How was your day?", "Pretty productive. I spent time learning about {}.", "That's a good use of time. Was it helpful?"),
        ("Any plans for later?", "I need to take care of something with the {}.", "Let me know if you need a hand."),
        ("What are you working on right now?", "I'm trying to figure out the best way to handle {}.", "That can be tricky. Have you made progress?"),
        ("How do you usually handle things?", "I always make sure to check the {} first.", "Smart approach. Preparation is key."),
    ],
    'food': [
        ("I'm hungry. What sounds good?", "How about {}? I've been craving it.", "Great choice! Where should we go?"),
        ("Have you tried {} before?", "Yes, it's delicious! You should definitely try it.", "I will. What does it taste like?"),
        ("What's your go-to meal?", "I never get tired of {}.", "I can see why. It's really good."),
        ("Do you like cooking?", "I do. My specialty is {}.", "Impressive! You'll have to teach me sometime."),
        ("Let's grab something to eat.", "OK! I know a place that serves amazing {}.", "Let's go. I'm looking forward to it."),
    ],
    'family': [
        ("How's your family doing?", "Everyone's good. My {} has been keeping us busy.", "Family always comes first, doesn't it?"),
        ("Do you spend much time with family?", "Yes, especially with my {}. We're very close.", "That's nice. Having that bond is important."),
        ("Any family news?", "My {} just achieved something amazing.", "That's wonderful! Please send my congratulations."),
        ("What does your family like to do together?", "We enjoy activities involving {}.", "That sounds like quality time well spent."),
        ("Who do you look up to in your family?", "Definitely my {}. They inspire me every day.", "That's really touching. You're lucky."),
    ],
    'weather': [
        ("Nice weather we're having.", "Yes, the {} conditions are perfect today.", "Let's make the most of it while it lasts."),
        ("Did you check the forecast?", "Yeah, they say it'll be {} tomorrow.", "Good to know. I'll plan accordingly."),
        ("I love days like this.", "Me too. {} weather always lifts my spirits.", "Couldn't agree more."),
        ("Think it might rain?", "The sky looks {}. I'd bring an umbrella just in case.", "Good call. Better safe than sorry."),
        ("What's your favorite season?", "I enjoy {} the most. The weather is just right.", "Same here. It's the perfect time of year."),
    ],
    'animal': [
        ("Do you like animals?", "I love them. My favorite is the {}.", "What do you like most about it?"),
        ("Ever been to a zoo or aquarium?", "Yes! I saw a {} there. It was incredible.", "I'd love to see one in person someday."),
        ("Have you thought about getting a pet?", "I'm considering getting a {}.", "That's a great choice. They're wonderful companions."),
        ("What's the most interesting animal you know?", "I find the {} fascinating. There's so much to learn about it.", "Tell me one interesting fact."),
        ("Look at that wildlife!", "It reminds me of a {}. So beautiful.", "Nature really is amazing."),
    ],
    'professional': [
        ("Can you explain the term {}?", "Absolutely. {} refers to a key concept in this field.", "Got it. How is it applied in practice?"),
        ("What's the status on the {}?", "I've reviewed the {}. Everything looks good.", "Great. Let me know if anything changes."),
        ("We need to check the {} specifications.", "The {} details are in the documentation.", "Perfect. I'll look them up right now."),
        ("Is the {} ready for review?", "Almost done. The {} just needs final confirmation.", "OK. Take your time and make sure it's right."),
        ("How does the {} work exactly?", "The {} operates based on a straightforward principle.", "Could you walk me through the steps?"),
        ("Any issues with the {}?", "No, the {} is functioning as expected.", "Good to hear. Let's keep monitoring it."),
        ("I have a question about {}.", "Sure, what would you like to know about {}?", "I'm curious about its main purpose."),
        ("Let's discuss the {} in more detail.", "Good idea. The {} is central to our work.", "Agreed. Let's start with the basics."),
    ],
    'general': [
        ("What are you thinking about?", "I've been curious about {} lately.", "That's interesting. What got you started?"),
        ("Tell me something interesting.", "Did you know about {}? It's quite fascinating.", "I hadn't thought about it that way. Tell me more."),
        ("What's something you've learned recently?", "I discovered more about {}. It really surprised me.", "That's unexpected. Can you explain further?"),
        ("What do you find most interesting?", "For me, it's {}. There's so much to explore.", "I can see why. It's a deep topic."),
        ("Is there anything you're passionate about?", "I really enjoy learning about {}.", "That's a great interest. How did you get into it?"),
        ("What keeps you motivated?", "Working on {} always keeps me engaged.", "I admire your dedication. Keep it up."),
        ("Any recommendations for something new to explore?", "You should look into {}. It's worth your time.", "Thanks for the suggestion. I'll check it out."),
        ("What's a skill you'd like to develop?", "I want to get better at {}.", "That's a valuable skill to have."),
    ],
}

# Merge custom scenarios into SCENARIOS (context-aware dialogues)
if CUSTOM_SCENARIOS:
    SCENARIOS.update(CUSTOM_SCENARIOS)
    print(f'Merged {len(CUSTOM_SCENARIOS)} custom scenario groups into SCENARIOS')

def pick_scenario(word, chinese):
    """Pick appropriate scenario based on word meaning."""
    w = str(word).lower() if not pd.isna(word) else ''
    c = str(chinese) if not pd.isna(chinese) else ''

    animals_set = {'dog','cat','bird','fish','horse','rabbit','duck','pig','cow','sheep',
                   'chicken','frog','bear','monkey','tiger','lion','elephant','snake','mouse',
                   'panda','pet','animal','hen','goose','parrot','turtle','ant','bee'}
    if w in animals_set or any(a in c for a in ['鸟','狗','猫','鱼','马','兔','鸭','猪','牛','羊',
                                                  '鸡','蛙','熊','猴','虎','狮','象','蛇','鼠','熊猫',
                                                  '宠物','动物','鹅','龟','蚂蚁','蜜蜂']):
        return 'animal'

    foods_set = {'food','fruit','apple','banana','orange','rice','bread','milk','egg',
                 'cake','noodle','soup','meat','vegetable','tomato','potato',
                 'beef','pork','juice','water','tea','coffee','candy','chocolate',
                 'hamburger','pizza','breakfast','lunch','dinner','supper','meal'}
    if w in foods_set or any(a in c for a in ['吃','喝','食物','水果','饭','菜','汤','蛋','奶','糖',
                                                '饮料','早餐','午餐','晚餐']):
        return 'food'

    weather_set = {'weather','sun','rain','wind','cloud','snow','hot','cold','warm','cool',
                   'sunny','rainy','cloudy','windy','snowy','wet','dry','storm'}
    if w in weather_set or any(a in c for a in ['天气','晴','雨','风','云','雪','冷','热','暖','凉',
                                                  '湿','干','暴风雨']):
        return 'weather'

    family_set = {'mother','father','sister','brother','family','aunt','uncle','grandma',
                  'grandpa','cousin','parent','baby','daughter','son','wife','husband'}
    if w in family_set or any(a in c for a in ['妈妈','爸爸','姐妹','兄弟','家庭','阿姨','叔叔',
                                                 '奶奶','爷爷','表','父母','婴儿','孩子','儿','女']):
        return 'family'

    greeting_set = {'hello','hi','goodbye','bye','morning','afternoon','evening','night',
                    'welcome','please','thanks','sorry','excuse','fine','nice','meet'}
    if w in greeting_set or any(a in c for a in ['你好','再见','早上','下午','晚上','欢迎','请','谢谢',
                                                   '对不起','打扰','好的','见面']):
        return 'greeting'

    word_count = len(w.split())
    if word_count >= 3:
        return 'professional'
    if len(w) > 10 and ' ' not in w:
        return 'professional'
    tech_keywords = ['机','器','件','板','管','门','窗','锁','框','条','料','锯','钻','焊',
                     '螺','阀','泵','轴','轮','链','带','轨','架','座','箱','壳','芯','片',
                     '系统','设备','装置','结构','工艺','材料','部件','组件','模具','夹具',
                     '软件','硬件','程序','模块','接口','协议','配置','参数','算法']
    if any(kw in c for kw in tech_keywords):
        return 'professional'

    # If custom scenarios exist, use them for general/professional words
    if CUSTOM_SCENARIOS and (len(w.split()) >= 2 or len(w) > 8):
        # Multi-word terms and longer words are likely domain-specific
        custom_keys = list(CUSTOM_SCENARIOS.keys())
        return random.choice(custom_keys)

    return 'general'


def validate_dialogue(lines, word_en):
    """Post-generation validation: ensure NO Chinese characters in any dialogue line."""
    cleaned = []
    w = str(word_en)
    for speaker, text in lines:
        if has_chinese(text):
            fixed = re.sub(r'[\u4e00-\u9fff]+', '', text)
            fixed = re.sub(r'\s{2,}', ' ', fixed).strip()
            fixed = re.sub(r'\s([.,!?;:])', r'\1', fixed)
            if len(fixed) < 10:
                fixed = f'I was just reading about "{w}".'
            cleaned.append((speaker, fixed))
        else:
            cleaned.append((speaker, text))
    return cleaned


def generate_dialogue(word, chinese, scenario):
    """Generate 3-round A/B/A dialogue. Guaranteed to contain ZERO Chinese characters."""
    templates = SCENARIOS.get(scenario, SCENARIOS['general'])
    template = random.choice(templates)

    w = str(word).strip()
    if not w:
        w = 'this term'

    lines = []
    for i, tpl in enumerate(template):
        if '{}' in tpl:
            filled = tpl.format(w)
        else:
            filled = tpl

        if i == 1 and w.lower() not in filled.lower():
            parts = filled.split()
            if len(parts) > 3:
                idx = random.randint(1, len(parts) - 1)
                parts.insert(idx, w)
                filled = ' '.join(parts)
            else:
                filled = filled.rstrip('.!?') + f'. For instance, consider "{w}".'

        speaker = 'A' if (i == 0 or i == 2) else 'B'
        lines.append((speaker, filled))

    lines = validate_dialogue(lines, w)
    return lines


# ── Generate dialogues for all words ────────────────────────────
all_dialogues = []
all_sentences = set()

for i in range(TOTAL):
    row = df.iloc[i]
    word_en = str(row[col_word]).strip() if col_word and not pd.isna(row[col_word]) else ''
    chinese = str(row[col_cn]).strip() if col_cn and not pd.isna(row[col_cn]) else ''

    if has_chinese(word_en):
        word_en = strip_chinese(word_en)
        if not word_en:
            word_en = '(term)'

    scenario = pick_scenario(word_en, chinese)
    dialogue = generate_dialogue(word_en, chinese, scenario)
    all_dialogues.append(dialogue)

    for _, text in dialogue:
        all_sentences.add(text)

all_sentences_sorted = sorted(all_sentences)
print(f'Unique dialogue sentences: {len(all_sentences_sorted)}')

# ── Extract sentences mode: write JSON and exit ────────────────
if args.extract_sentences:
    input_dir = os.path.dirname(os.path.abspath(args.input))
    sentences_path = os.path.join(input_dir, 'unique_sentences.json')
    with open(sentences_path, 'w', encoding='utf-8') as f:
        json.dump(all_sentences_sorted, f, ensure_ascii=False, indent=2)
    print(f'Written {len(all_sentences_sorted)} unique sentences to {sentences_path}')
    print('Now use AI to translate all sentences and save as cn_translations.py:')
    print('  CN = {"english sentence": "中文翻译", ...}')
    print('Then re-run this script without --extract-sentences to build the final HTML.')
    sys.exit(0)

# ── Load Chinese translations ──────────────────────────────────
CN = {}
trans_path = args.translations
if not trans_path:
    input_dir = os.path.dirname(os.path.abspath(args.input))
    candidate = os.path.join(input_dir, 'cn_translations.py')
    if os.path.exists(candidate):
        trans_path = candidate

if trans_path and os.path.exists(trans_path):
    print(f'Loading translations from: {trans_path}')
    spec = importlib.util.spec_from_file_location("cn_translations", trans_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    CN = mod.CN
    print(f'  Loaded {len(CN)} translations')

    # Check coverage
    missing = [s for s in all_sentences_sorted if s not in CN]
    if missing:
        print(f'  WARNING: {len(missing)} sentences missing translations!')
        print(f'  Coverage: {len(CN)}/{len(all_sentences_sorted)} ({100*len(CN)//len(all_sentences_sorted)}%)')
        print(f'  Missing sentences will not show "中" button.')
    else:
        print(f'  Coverage: 100% ({len(CN)}/{len(all_sentences_sorted)})')
else:
    print('No cn_translations.py found. HTML will be generated without Chinese translations.')
    print('To add translations:')
    print('  1. Run with --extract-sentences to get unique_sentences.json')
    print('  2. Use AI to translate all sentences → cn_translations.py')
    print('  3. Re-run this script to build HTML with translations')

# ── 3. Build HTML ───────────────────────────────────────────────
with open(TEMPLATE_PATH, 'r', encoding='utf-8') as f:
    html_template = f.read()

def grade_hint(idx):
    """Get grade/unit hint for section title."""
    row = df.iloc[idx]
    parts = []
    if col_grade:
        parts.append(str(row[col_grade]).strip())
    return ' '.join(parts)

def esc(text):
    """Escape text for safe HTML attribute and content embedding."""
    return str(text).replace('&', '&amp;').replace("'", '&#x27;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')

def esc_attr(text):
    """Escape text for HTML attribute values (less aggressive for data-cn)."""
    return str(text).replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')

# Generate all sections
all_sections = []
toc_items = []
word_counter = 0
cn_embedded_count = 0
cn_missing_count = 0
_dialogue_audio_idx = 0  # Global counter for dialogue audio files
_word_id_list = []       # Collect (wid, word_text) for words_list.txt

for sec_idx in range(TOTAL_SECTIONS):
    start_idx = sec_idx * WORDS_PER_SECTION
    end_idx = min(start_idx + WORDS_PER_SECTION, TOTAL)

    cards = []
    for i in range(start_idx, end_idx):
        row = df.iloc[i]
        word_counter += 1
        N = word_counter

        word_en = str(row[col_word]).strip() if col_word and not pd.isna(row[col_word]) else ''
        chinese = str(row[col_cn]).strip() if col_cn and not pd.isna(row[col_cn]) else ''
        grade = str(row[col_grade]).strip() if col_grade and not pd.isna(row[col_grade]) else ''
        unit = str(row[col_unit]).strip() if col_unit and not pd.isna(row[col_unit]) else ''

        if has_chinese(word_en):
            word_en = strip_chinese(word_en)
            if not word_en:
                word_en = '(term)'

        uk, us = parse_phonetic(row[col_ph]) if col_ph else ('', '')
        etymology = clean_etymology(row[col_etym]) if col_etym else '暂无词根词缀信息'
        wtype = guess_word_type(chinese)
        definition = get_definition(word_en, chinese, wtype)

        dialogue = all_dialogues[i]

        wid = random.randint(10000, 99999)
        ids = [random.randint(10000, 99999) for _ in range(3)]
        _word_id_list.append((wid, word_en))

        lang_hint = f'({grade} {unit})'.strip() if grade or unit else ''

        uk_display = uk if uk else '/.../'
        us_display = us if us else '/.../'
        phonetic_html = f'<span class="phonetic">英:{uk_display} 美:{us_display}</span>' if (uk or us) else ''

        # Build dialogue lines with pre-embedded Chinese translations
        dialogue_lines_html = ''
        for di, (speaker, text) in enumerate(dialogue):
            line_class = 'a' if speaker == 'A' else 'b'
            line_id = f'l_{di}_{ids[di]}'
            cn_text = CN.get(text, '')

            if cn_text:
                cn_embedded_count += 1
                cn_html = f'<span class="cn-tip">{esc(cn_text)}</span>'
                cn_hint_html = '<span class="cn-hint">中</span>'
            else:
                cn_missing_count += 1
                cn_html = ''
                cn_hint_html = ''

            audio_attr = f' data-audio="audio/d_{_dialogue_audio_idx:04d}.mp3"'
            _dialogue_audio_idx += 1
            dialogue_lines_html += f'''<div class="line {line_class}" onclick="toggleCn(this)" data-en="{esc_attr(text)}"{audio_attr}><span class="speaker">{speaker}</span><span class="en-text">{esc(text)}</span>{cn_hint_html}<button class="btn-speak-dlg-line" onclick="event.stopPropagation();speakText(this.parentElement)" title="朗读此行" aria-label="朗读">🔊</button>{cn_html}</div>'''

        card_html = f'''<div class="card" id="w{N}" data-word-num="{N}" data-word="{esc(word_en)}">
  <div class="card-header">
    <span class="num">{N}</span>
    <span class="word" id="word_{wid}" data-audio-word="audio/words/w_{wid}.mp3">{esc(word_en)}</span>
    <button class="btn-speak word-speak" onclick="speakWord('word_{wid}')" title="朗读单词" aria-label="朗读">🔊</button>
    {phonetic_html}
    <button class="btn-review" onclick="toggleReview('{N}')" title="加入/移出复习组" aria-label="复习">📝 复习</button>
  </div>
  <div class="definition">📖 {esc(definition)}{' <span style="color:#94a3b8;font-size:.75rem">' + esc(lang_hint) + '</span>' if lang_hint else ''}</div>
  <div class="root">🌱 <strong>词根词缀：</strong> {esc(etymology)}</div>
  <div class="dialogue-box">
    <div class="dialogue-label">
      💬 场景对话
      <button class="btn-speak-dlg" onclick="speakDialogue(this.parentElement.parentElement)" title="朗读全部对话" aria-label="朗读对话">🔊 读对话</button>
    </div>
    {dialogue_lines_html}
  </div>
</div>'''
        cards.append(card_html)

    section_id = sec_idx + 1
    start_word = start_idx + 1
    end_word = end_idx

    section_html = f'''<section id="sec{section_id}">
  <h2 class="section-title">第 {section_id} 组 &nbsp;#{start_word}–{end_word}</h2>
  {''.join(cards)}
  <div class="back-top"><a href="javascript:void(0)" onclick="scrollTo(0,0)">▲ 返回顶部</a></div>
</section>'''

    all_sections.append(section_html)
    toc_items.append(f'<a href="#sec{section_id}" class="toc-item">{start_word}–{end_word}</a>')

    if (sec_idx + 1) % 5 == 0:
        print(f'  Built section {sec_idx + 1}/{TOTAL_SECTIONS}')

print('All sections built.')
print(f'Chinese translations embedded: {cn_embedded_count}')
if cn_missing_count > 0:
    print(f'WARNING: {cn_missing_count} dialogue lines have no translation (no "中" button shown).')

# ── 4. Write HTML ──────────────────────────────────────────────
output = html_template
output = output.replace('{{TITLE}}', TITLE)
output = output.replace('{{TOTAL}}', str(TOTAL))
output = output.replace('{{REVIEW_KEY}}', REVIEW_KEY)
output = output.replace('{{TOC_ITEMS}}', '\n'.join(toc_items))
output = output.replace('{{SECTIONS}}', '\n'.join(all_sections))

os.makedirs(args.output, exist_ok=True)
output_filename = re.sub(r'[^\w\u4e00-\u9fff]', '_', TITLE) + '.html'
output_path = os.path.join(args.output, output_filename)

with open(output_path, 'w', encoding='utf-8') as f:
    f.write(output)

file_size = os.path.getsize(output_path)
print(f'Done! {TOTAL} words -> {output_path}')
print(f'File size: {file_size / 1024:.0f} KB')
print(f'Sections: {TOTAL_SECTIONS} groups of {WORDS_PER_SECTION}')
if cn_embedded_count > 0:
    print(f'Chinese translations embedded: {cn_embedded_count}')
print(f'Dialogue audio files needed: {_dialogue_audio_idx}')

# ── 5. Write words_list.txt for gen_word_audio.py ──────────────
words_list_path = os.path.join(args.output, 'words_list.txt')
with open(words_list_path, 'w', encoding='utf-8') as wf:
    for wid_val, word_text in _word_id_list:
        wf.write(f'word_{wid_val}\t{word_text}\n')
print(f'Words list written to {words_list_path} ({len(_word_id_list)} entries)')
