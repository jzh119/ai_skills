#!/usr/bin/env python3
"""
extract_words.py — Universal word extractor for vocab-html-builder

Supports input formats: xlsx, csv, txt, pdf, docx

For structured files (xlsx, csv):
  - Auto-detects columns (word, chinese, phonetic, etymology, grade, unit)
  - Outputs normalized words_normalized.csv

For unstructured files (txt, pdf, docx):
  - Extracts full text content
  - Outputs raw_text.txt for AI to read and identify vocabulary words
  - AI then creates words_normalized.csv manually

Output format (words_normalized.csv):
  word,chinese,phonetic,etymology
  apple,苹果,/ˈæpəl/,apple tree fruit
  ...

Usage:
  python extract_words.py <input_file> [--output <dir>]

Dependencies:
  - pandas + openpyxl (for xlsx)
  - python-docx (for docx): pip install python-docx
  - pdfplumber (for pdf): pip install pdfplumber
"""

import os
import sys
import re
import argparse
import csv

def parse_args():
    parser = argparse.ArgumentParser(
        description='Extract English vocabulary words from any file format'
    )
    parser.add_argument('input', help='Input file path (xlsx/csv/txt/pdf/docx)')
    parser.add_argument('--output', default='.', help='Output directory (default: current dir)')
    return parser.parse_args()

args = parse_args()
sys.stdout.reconfigure(encoding='utf-8')

INPUT = args.input
OUTPUT_DIR = args.output
EXT = os.path.splitext(INPUT)[1].lower()

if not os.path.exists(INPUT):
    print(f'ERROR: File not found: {INPUT}')
    sys.exit(1)

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── Helper functions ────────────────────────────────────────────

def has_chinese(text):
    if not text or (isinstance(text, float) and str(text) == 'nan'):
        return False
    return bool(re.search(r'[\u4e00-\u9fff]', str(text)))

def is_english_word(text):
    """Check if text looks like an English word/phrase."""
    if not text:
        return False
    t = str(text).strip()
    if not t:
        return False
    if has_chinese(t):
        return False
    # Must contain at least one ASCII letter
    if not re.search(r'[a-zA-Z]', t):
        return False
    # Allow letters, spaces, hyphens, apostrophes
    if not re.match(r"^[a-zA-Z][a-zA-Z\s\-']*[a-zA-Z]$", t):
        return False
    return True

# ── Structured file parsers ────────────────────────────────────

def parse_xlsx(filepath):
    """Parse xlsx file and return list of dicts."""
    import pandas as pd
    df = pd.read_excel(filepath)
    cols = list(df.columns)
    print(f'Columns: {cols}')

    col_word = None
    col_cn = None
    col_ph = None
    col_etym = None
    col_grade = None
    col_unit = None

    for c in cols:
        cl = str(c).lower()
        if '年级' in cl or 'grade' in cl:
            col_grade = c
        elif '单元' in cl or 'unit' in cl:
            col_unit = c
        elif any(k in cl for k in ['单词', 'english', '英文', '术语', 'word']):
            col_word = c
        elif any(k in cl for k in ['中文', 'chinese', '释义', '翻译', 'meaning', 'translation']):
            col_cn = c
        elif any(k in cl for k in ['音标', 'phonetic']):
            col_ph = c
        elif any(k in cl for k in ['词根', '词源', 'etymology', 'etym']):
            col_etym = c

    # Fallback: use column index
    if not col_word:
        col_word = cols[2] if len(cols) > 2 else cols[0]
    if not col_cn:
        col_cn = cols[3] if len(cols) > 3 else (cols[1] if len(cols) > 1 else None)

    # Auto-detect and fix swapped columns
    if col_word and col_cn:
        sample_words = df[col_word].dropna().head(20)
        cn_in_word = sum(1 for v in sample_words if has_chinese(v))
        if cn_in_word > len(sample_words) * 0.3:
            print(f'WARNING: word column contains Chinese. Auto-swapping.')
            col_word, col_cn = col_cn, col_word

    print(f'Column mapping: word={col_word}, cn={col_cn}, ph={col_ph}, etym={col_etym}')

    words = []
    for _, row in df.iterrows():
        word = str(row[col_word]).strip() if col_word and not pd.isna(row[col_word]) else ''
        cn = str(row[col_cn]).strip() if col_cn and not pd.isna(row[col_cn]) else ''
        ph = str(row[col_ph]).strip() if col_ph and not pd.isna(row[col_ph]) else ''
        etym = str(row[col_etym]).strip() if col_etym and not pd.isna(row[col_etym]) else ''

        if has_chinese(word):
            word = re.sub(r'[\u4e00-\u9fff]+', '', word).strip()
        if not word:
            continue

        words.append({
            'word': word,
            'chinese': cn,
            'phonetic': ph,
            'etymology': etym
        })

    return words


def parse_csv(filepath):
    """Parse CSV file and return list of dicts."""
    import pandas as pd
    # Try common encodings
    for enc in ['utf-8', 'gbk', 'gb2312', 'latin-1']:
        try:
            df = pd.read_csv(filepath, encoding=enc)
            break
        except (UnicodeDecodeError, Exception):
            continue
    else:
        print('ERROR: Could not decode CSV file. Try converting to UTF-8.')
        sys.exit(1)

    cols = list(df.columns)
    print(f'Columns: {cols}')

    # Reuse same column detection logic as xlsx
    col_word = None
    col_cn = None
    col_ph = None
    col_etym = None

    for c in cols:
        cl = str(c).lower()
        if any(k in cl for k in ['单词', 'english', '英文', '术语', 'word']):
            col_word = c
        elif any(k in cl for k in ['中文', 'chinese', '释义', '翻译', 'meaning', 'translation']):
            col_cn = c
        elif any(k in cl for k in ['音标', 'phonetic']):
            col_ph = c
        elif any(k in cl for k in ['词根', '词源', 'etymology', 'etym']):
            col_etym = c

    if not col_word:
        col_word = cols[0]
    if not col_cn and len(cols) > 1:
        col_cn = cols[1]

    # Auto-detect swapped columns
    if col_word and col_cn:
        sample_words = df[col_word].dropna().head(20)
        cn_in_word = sum(1 for v in sample_words if has_chinese(v))
        if cn_in_word > len(sample_words) * 0.3:
            print(f'WARNING: word column contains Chinese. Auto-swapping.')
            col_word, col_cn = col_cn, col_word

    words = []
    for _, row in df.iterrows():
        word = str(row[col_word]).strip() if col_word and not pd.isna(row[col_word]) else ''
        cn = str(row[col_cn]).strip() if col_cn and not pd.isna(row[col_cn]) else ''
        ph = str(row[col_ph]).strip() if col_ph and not pd.isna(row[col_ph]) else ''
        etym = str(row[col_etym]).strip() if col_etym and not pd.isna(row[col_etym]) else ''

        if has_chinese(word):
            word = re.sub(r'[\u4e00-\u9fff]+', '', word).strip()
        if not word:
            continue

        words.append({
            'word': word,
            'chinese': cn,
            'phonetic': ph,
            'etymology': etym
        })

    return words


# ── Unstructured file parsers ──────────────────────────────────

def parse_txt(filepath):
    """Extract text from a plain text file."""
    for enc in ['utf-8', 'gbk', 'gb2312', 'latin-1']:
        try:
            with open(filepath, 'r', encoding=enc) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    print('ERROR: Could not decode text file.')
    sys.exit(1)


def parse_pdf(filepath):
    """Extract text from a PDF file using pdfplumber."""
    try:
        import pdfplumber
    except ImportError:
        print('ERROR: pdfplumber not installed. Install with: pip install pdfplumber')
        sys.exit(1)

    text_parts = []
    with pdfplumber.open(filepath) as pdf:
        for i, page in enumerate(pdf.pages):
            text = page.extract_text() or ''
            text_parts.append(text)
            print(f'  Page {i+1}: {len(text)} chars')
    return '\n\n'.join(text_parts)


def parse_docx(filepath):
    """Extract text from a Word document using python-docx."""
    try:
        from docx import Document
    except ImportError:
        print('ERROR: python-docx not installed. Install with: pip install python-docx')
        sys.exit(1)

    doc = Document(filepath)
    paragraphs = []
    for para in doc.paragraphs:
        if para.text.strip():
            paragraphs.append(para.text)

    # Also extract text from tables
    for table in doc.tables:
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            if any(cells):
                paragraphs.append('\t'.join(cells))

    return '\n\n'.join(paragraphs)


# ── Write normalized CSV ───────────────────────────────────────

def write_normalized_csv(words, output_path):
    """Write normalized words to CSV."""
    with open(output_path, 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['word', 'chinese', 'phonetic', 'etymology'])
        writer.writeheader()
        for w in words:
            writer.writerow({
                'word': w.get('word', ''),
                'chinese': w.get('chinese', ''),
                'phonetic': w.get('phonetic', ''),
                'etymology': w.get('etymology', '')
            })
    print(f'Written {len(words)} words to {output_path}')


def write_raw_text(text, output_path):
    """Write raw text for AI processing."""
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(text)
    print(f'Written {len(text)} chars to {output_path}')


# ── Main ───────────────────────────────────────────────────────

print(f'Input: {INPUT}')
print(f'Format: {EXT}')
print(f'Output dir: {OUTPUT_DIR}')
print()

if EXT in ('.xlsx', '.xls'):
    words = parse_xlsx(INPUT)
    output_path = os.path.join(OUTPUT_DIR, 'words_normalized.csv')
    write_normalized_csv(words, output_path)
    print(f'\nDone! {len(words)} words extracted.')
    print(f'Next step: Run build_vocab.py with words_normalized.csv')

elif EXT == '.csv':
    words = parse_csv(INPUT)
    output_path = os.path.join(OUTPUT_DIR, 'words_normalized.csv')
    write_normalized_csv(words, output_path)
    print(f'\nDone! {len(words)} words extracted.')
    print(f'Next step: Run build_vocab.py with words_normalized.csv')

elif EXT == '.txt':
    text = parse_txt(INPUT)
    raw_path = os.path.join(OUTPUT_DIR, 'raw_text.txt')
    write_raw_text(text, raw_path)
    print(f'\nDone! Raw text extracted ({len(text)} chars).')
    print(f'Next step: AI reads raw_text.txt, identifies vocabulary words,')
    print(f'            and creates words_normalized.csv with columns:')
    print(f'            word,chinese,phonetic,etymology')

elif EXT == '.pdf':
    text = parse_pdf(INPUT)
    raw_path = os.path.join(OUTPUT_DIR, 'raw_text.txt')
    write_raw_text(text, raw_path)
    print(f'\nDone! Raw text extracted ({len(text)} chars).')
    print(f'Next step: AI reads raw_text.txt, identifies vocabulary words,')
    print(f'            and creates words_normalized.csv with columns:')
    print(f'            word,chinese,phonetic,etymology')

elif EXT in ('.docx', '.doc'):
    text = parse_docx(INPUT)
    raw_path = os.path.join(OUTPUT_DIR, 'raw_text.txt')
    write_raw_text(text, raw_path)
    print(f'\nDone! Raw text extracted ({len(text)} chars).')
    print(f'Next step: AI reads raw_text.txt, identifies vocabulary words,')
    print(f'            and creates words_normalized.csv with columns:')
    print(f'            word,chinese,phonetic,etymology')

else:
    print(f'ERROR: Unsupported file format: {EXT}')
    print(f'Supported formats: xlsx, csv, txt, pdf, docx')
    sys.exit(1)
