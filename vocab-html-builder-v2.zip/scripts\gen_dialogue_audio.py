#!/usr/bin/env python3
"""
gen_dialogue_audio.py — Generate neural TTS audio for all dialogue lines

Reads the generated HTML file, extracts all dialogue lines with their
speaker roles (A=male, B=female), and generates MP3 files using edge-tts.

Features:
  - Male voice (A): en-US-GuyNeural
  - Female voice (B): en-US-JennyNeural
  - Parallel generation (8 concurrent tasks)
  - Skip already-generated files
  - Retry on failure

The HTML must already contain data-audio="audio/d_XXXX.mp3" attributes
on each dialogue line (added by build_vocab.py at build time).

Usage:
  python gen_dialogue_audio.py <html_file> [--audio-dir <dir>] [--concurrency <n>]

Dependencies:
  pip install edge-tts

Example:
  python gen_dialogue_audio.py my_vocab.html --audio-dir ./audio
"""

import asyncio
import os
import re
import sys
import html as html_module
import argparse

def parse_args():
    parser = argparse.ArgumentParser(
        description='Generate neural TTS dialogue audio from HTML file'
    )
    parser.add_argument('html_file', help='Path to the generated HTML file')
    parser.add_argument('--audio-dir', default='audio', help='Output directory for audio files (default: audio)')
    parser.add_argument('--concurrency', type=int, default=8, help='Concurrent TTS tasks (default: 8)')
    return parser.parse_args()

args = parse_args()
sys.stdout.reconfigure(encoding='utf-8')


def extract_dialogue_lines(html_content):
    """
    Extract dialogue lines from HTML.
    Returns list of (audio_filename, role, text) tuples.
    """
    # Match: <div class="line [ab]" ... data-audio="audio/d_XXXX.mp3" ... data-en="text" ...>
    pattern = re.compile(
        r'<div class="line ([ab])"[^>]*data-audio="([^"]*)"[^>]*data-en="([^"]*)"',
        re.IGNORECASE
    )
    matches = pattern.findall(html_content)

    results = []
    for role, audio_path, text in matches:
        # Unescape HTML entities
        clean_text = html_module.unescape(text)
        results.append((audio_path, role.lower(), clean_text))

    return results


async def generate_one(text, voice, filepath, sem, retries=3):
    """Generate a single MP3 file with retries."""
    async with sem:
        # Skip if already exists and is non-trivial size
        if os.path.exists(filepath) and os.path.getsize(filepath) > 100:
            return True

        for attempt in range(retries):
            try:
                import edge_tts
                communicate = edge_tts.Communicate(text, voice)
                await communicate.save(filepath)
                return True
            except Exception as e:
                if attempt == retries - 1:
                    print(f"  FAIL: {text[:60]}... ({e})")
                    return False
                await asyncio.sleep(1)
        return False


async def main():
    # Read HTML file
    if not os.path.exists(args.html_file):
        print(f'ERROR: HTML file not found: {args.html_file}')
        sys.exit(1)

    with open(args.html_file, 'r', encoding='utf-8') as f:
        html_content = f.read()

    # Extract dialogue lines
    lines = extract_dialogue_lines(html_content)
    print(f'Found {len(lines)} dialogue lines in HTML')

    if not lines:
        print('ERROR: No dialogue lines found. Make sure the HTML was built with build_vocab.py')
        print('       (build_vocab.py adds data-audio attributes at build time)')
        sys.exit(1)

    # Create audio directory
    os.makedirs(args.audio_dir, exist_ok=True)

    # Check which files already exist
    missing = []
    for audio_path, role, text in lines:
        filepath = os.path.join(os.path.dirname(args.html_file), audio_path) \
            if not os.path.isabs(audio_path) else audio_path
        # If audio_path is relative like "audio/d_0000.mp3", use audio_dir
        if audio_path.startswith('audio/'):
            filepath = os.path.join(os.path.dirname(args.html_file) or '.', audio_path)
        if not os.path.exists(filepath) or os.path.getsize(filepath) < 100:
            missing.append((audio_path, role, text))

    print(f'Already exist: {len(lines) - len(missing)}, Need to generate: {len(missing)}')

    if not missing:
        print('All dialogue MP3s already generated!')
        return

    # Generate in parallel batches
    sem = asyncio.Semaphore(args.concurrency)
    total = len(missing)
    done = 0
    failed = 0

    batch_size = args.concurrency * 2

    for i in range(0, total, batch_size):
        batch = missing[i:i + batch_size]
        tasks = []
        for audio_path, role, text in batch:
            voice = 'en-US-GuyNeural' if role == 'a' else 'en-US-JennyNeural'
            filepath = os.path.join(os.path.dirname(args.html_file) or '.', audio_path)
            # Ensure subdirectory exists
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            tasks.append(generate_one(text, voice, filepath, sem))

        results = await asyncio.gather(*tasks, return_exceptions=True)
        for j, r in enumerate(results):
            if isinstance(r, Exception) or r is False:
                failed += 1
            else:
                done += 1

        print(f'  Progress: {done}/{total} generated, {failed} failed')

    # Verify
    ok = 0
    bad = 0
    for audio_path, role, text in lines:
        filepath = os.path.join(os.path.dirname(args.html_file) or '.', audio_path)
        if os.path.exists(filepath) and os.path.getsize(filepath) > 100:
            ok += 1
        else:
            bad += 1

    total_size = 0
    for audio_path, _, _ in lines:
        filepath = os.path.join(os.path.dirname(args.html_file) or '.', audio_path)
        if os.path.exists(filepath):
            total_size += os.path.getsize(filepath)

    print(f'\n{"="*60}')
    print(f'Done! OK: {ok}, Missing/Bad: {bad}')
    print(f'Total audio size: {total_size / 1024 / 1024:.1f} MB')
    print(f'Audio directory: {args.audio_dir}/')
    print(f'{"="*60}')


if __name__ == '__main__':
    asyncio.run(main())
